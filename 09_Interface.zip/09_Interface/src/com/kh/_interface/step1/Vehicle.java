package com.kh._interface.step1;

public interface Vehicle {

	/*public abstract*/ void run();
	
}
