package com.kh._interface.step3;

public interface RemoteControl {

	void turnOn();
	void turnOff();
	
}
