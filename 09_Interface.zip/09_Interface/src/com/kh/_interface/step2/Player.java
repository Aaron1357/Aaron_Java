package com.kh._interface.step2;

public interface Player {

	void run();
	void jump();
	void turn();
	void showLevelMessage();
	
}
